//
//  MesonUnityAdapter.h
//  MesonUnityAdapter
//
//  Created by vikas kumar jangir on 21/10/21.
//

#import <Foundation/Foundation.h>

//! Project version number for MesonUnityAdapter.
FOUNDATION_EXPORT double MesonUnityAdapterVersionNumber;

//! Project version string for MesonUnityAdapter.
FOUNDATION_EXPORT const unsigned char MesonUnityAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MesonUnityAdapter/PublicHeader.h>


