===================================
InMobi Monetization SDK for iOS
===================================

This is the InMobi Monetization SDK 9.x for iOS

Requirements:
- An InMobi account ID and placement ID.
- Xcode 11.0 or later.
- Runtime of iOS 9.0 or later.

The full changelog can be found in the CHANGELOG file.

The latest documentation and code samples are available at:
https://support.inmobi.com/monetize
