//
//  MesonApplovinAdapter.h
//  MesonApplovinAdapter
//
//  Created by vikas kumar jangir on 29/10/21.
//

#import <Foundation/Foundation.h>

//! Project version number for MesonApplovinAdapter.
FOUNDATION_EXPORT double MesonApplovinAdapterVersionNumber;

//! Project version string for MesonApplovinAdapter.
FOUNDATION_EXPORT const unsigned char MesonApplovinAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MesonApplovinAdapter/PublicHeader.h>


