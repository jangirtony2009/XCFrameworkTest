//
//  MesonAdmobAdapter.h
//  MesonAdmobAdapter
//
//  Created by vikas kumar jangir on 29/10/21.
//

#import <Foundation/Foundation.h>

//! Project version number for MesonAdmobAdapter.
FOUNDATION_EXPORT double MesonAdmobAdapterVersionNumber;

//! Project version string for MesonAdmobAdapter.
FOUNDATION_EXPORT const unsigned char MesonAdmobAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MesonAdmobAdapter/PublicHeader.h>


