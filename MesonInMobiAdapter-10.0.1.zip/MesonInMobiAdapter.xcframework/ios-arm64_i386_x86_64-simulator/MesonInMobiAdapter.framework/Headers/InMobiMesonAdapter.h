//
//  InMobiMesonAdapter.h
//  InMobiMesonAdapter
//
//  Created by vikas kumar jangir on 28/07/21.
//

#import <Foundation/Foundation.h>

//! Project version number for InmobiMesonAdapter.
FOUNDATION_EXPORT double InmobiMesonAdapterVersionNumber;

//! Project version string for InmobiMesonAdapter.
FOUNDATION_EXPORT const unsigned char InmobiMesonAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InmobiMesonAdapter/PublicHeader.h>


