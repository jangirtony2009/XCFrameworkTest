===================================
Meson SDK for iOS
===================================

This is the Meson for iOS

Requirements:
- A meson appId and adUnitId. (https://meson.ai)
- Xcode 12.5 or later.
- Runtime of iOS 10.0 or later.

The full changelog can be found in the CHANGELOG file.

The latest documentation and code samples are available at:
https://docs.meson.ai/docs/intro

