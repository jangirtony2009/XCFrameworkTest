===================================
MesonGAMAdapter
===================================

## [8.12.0.0-beta5] - 2022-05-17
-------------

### Added Features
    - API Changes
    - Added support for ad formats
        ○ Native


## [8.12.0.0-beta4] - 2022-03-23
-------------

### Performance Improvements


## [8.12.0.0-beta3] - 2021-12-13
-------------

### Added Features
    - API Changes
    - Custom adapter support


## [8.12.0.0-beta1] - 2021-11-09
-------------

### Added Features
    - Support for GAM 8.12.0
    - Support for Passive Bidding
    - Added support for ad formats
        ○ Banner
        ○ Interstitial
        ○ Rewarded Video
