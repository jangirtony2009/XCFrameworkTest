//
//  MesonGAMAdapter.h
//  MesonGAMAdapter
//
//  Created by vikas kumar jangir on 29/10/21.
//

#import <Foundation/Foundation.h>

//! Project version number for MesonGAMAdapter.
FOUNDATION_EXPORT double MesonGAMAdapterVersionNumber;

//! Project version string for MesonGAMAdapter.
FOUNDATION_EXPORT const unsigned char MesonGAMAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MesonGAMAdapter/PublicHeader.h>


