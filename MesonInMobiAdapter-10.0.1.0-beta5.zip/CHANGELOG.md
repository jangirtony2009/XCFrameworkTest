===================================
MesonInMobiAdapter
===================================

## [10.0.1.0-beta5] - 2022-05-17
-------------

### API Changes


## [10.0.1.0-beta4] - 2022-03-23
-------------

### Performance Improvements


## [10.0.1.0-beta4] - 2021-12-13
-------------

### Added Features
    - API Changes
    - Custom adapter support


## [10.0.1.0-beta1] - 2021-11-09
-------------

### Added Features
    - Support for Inmobi 10.0.1
    - Support for Active Bidding
    - Added support for ad formats
        ○ Banner
        ○ Interstitial
        ○ Rewarded Video
        ○ Native (China only)
        ○ Splash (China only)
